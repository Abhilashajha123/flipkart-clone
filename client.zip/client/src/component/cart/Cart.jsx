import React from 'react'

const Cart = () => {
    return (
        <div>
            <h1>ijioiioio</h1>
        </div>
    )
}

export default Cart
